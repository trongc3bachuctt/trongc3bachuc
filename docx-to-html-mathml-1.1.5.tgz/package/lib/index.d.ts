export type DocxInput = Buffer | { buffer?: Buffer; path?: string };

export type ConvertOptions = {
    enableOmml?: boolean;
    enableMathType?: boolean;
    xsltPath?: string;
    rubyScriptPath?: string;
    rubyExe?: string;
    xsltprocExe?: string;
    wrapHtmlDocument?: boolean;
    ommlConcurrency?: number;
    deferredConcurrency?: number;
};

export function convertDocxToHtmlMathml(
    input: DocxInput,
    opts?: ConvertOptions
): Promise<string>;
